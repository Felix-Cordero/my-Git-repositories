<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}
?>
<!Doctype html>
<html>
<head>
<style>
form {
    width: 70%;
    padding: 16px;
    margin: auto;
    border-radius: 10px;
    border: 1px solid black;
}
p input, select {
    padding: 8px;
    margin: 4px;
    font-size: 1em;
}
p input[type="radio"], input[type="checkbox"] {
    width: 16px;
    height: 16px;
}
.red {
    color: red;
}
</style>
</head>
<body>
<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
	<p>Pet Profile Form</p>
	<p>Please tell us about your pet(s). Please fill out the form more than once for each pet you have.</p>
	<p><input type="text" name="firstname" placeholder="*First Name"  style="width:40%;" required><input type="text" name="lastname" placeholder="Last Name"  style="width:40%;" required></p>
	<p><input type="text" name="address1" placeholder="*Street Address 1"  style="width:90%;" required></p>
	<p><input type="text" name="address2" placeholder="Street Address 2" style="width:90%;"></p>
	<p><input type="text" name="city" placeholder="*City"  style="width:40%;" required><input type="text" name="state" placeholder="*State / Region"  style="width:40%;" required></p>
	<p><input type="number" name="postalcode" placeholder="*Postal Code"  style="width:40%;" required>
		<select name="country" style="width:40%;">
			<option value="Afghanistan">Afghanistan</option>
			<option value="�land Islands">Aland Islands</option>
			<option value="Albania">Albania</option>
			<option value="Algeria">Algeria</option>
			<option value="American Samoa">American Samoa</option>
			<option value="Andorra">Andorra</option>
			<option value="Angola">Angola</option>
			<option value="Anguilla">Anguilla</option>
			<option value="Antarctica">Antarctica</option>
			<option value="Antigua and Barbuda">Antigua and Barbuda</option>
			<option value="Argentina">Argentina</option>
			<option value="Armenia">Armenia</option>
			<option value="Aruba">Aruba</option>
			<option value="Australia">Australia</option>
			<option value="Austria">Austria</option>
			<option value="Azerbaijan">Azerbaijan</option>
			<option value="Bahamas">Bahamas</option>
			<option value="Bahrain">Bahrain</option>
			<option value="Bangladesh">Bangladesh</option>
			<option value="Barbados">Barbados</option>
			<option value="Belarus">Belarus</option>
			<option value="Belize">Belize</option>
			<option value="Benin">Benin</option>
			<option value="Bermuda">Bermuda</option>
			<option value="Bhutan">Bhutan</option>
			<option value="Bolivia">Bolivia</option>
			<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
			<option value="Botswana">Botswana</option>
			<option value="Bouvet Island">Bouvet Island</option>
			<option value="Brazil">Brazil</option>
			<option value="Brunei Darussalam">Brunei Darussalam</option>
			<option value="Bulgaria">Bulgaria</option>
			<option value="Burkina Faso">Burkina Faso</option>
			<option value="Burundi">Burundi</option>
			<option value="Cambodia">Cambodia</option>
			<option value="Cameroon">Cameroon</option>
			<option value="Canada">Canada</option>
			<option value="Cape Verde">Cape Verde</option>
			<option value="Cayman Islands">Cayman Islands</option>
			<option value="Central African Republic">Central African Republic</option>
			<option value="Chad">Chad</option>
			<option value="Chile">Chile</option>
			<option value="China">China</option>
			<option value="Christmas Island">Christmas Island</option>
			<option value="Keeling Islands">Keeling Islands</option>
			<option value="Colombia">Colombia</option>
			<option value="Comoros">Comoros</option>
			<option value="Congo">Congo</option>
			<option value="Cook Islands">Cook Islands</option>
			<option value="Costa Rica">Costa Rica</option>
			<option value="Costa Rica">Costa Rica</option>
			<option value="Croatia">Croatia</option>
			<option value="Cuba">Cuba</option>
			<option value="Cyprus">Cyprus</option>
			<option value="Czech Republic">Czech Republic</option>
			<option value="Denmark">Denmark</option>
			<option value="Djibouti">Djibouti</option>
			<option value="Dominica">Dominica</option>
			<option value="Dominican Republic">Dominican Republic</option>
			<option value="Ecuador">Ecuador</option>
			<option value="Egypt">Egypt</option>
			<option value="El Salvador">El Salvador</option>
			<option value="Equatorial Guinea">Equatorial Guinea</option>
			<option value="Eritrea">Eritrea</option>
			<option value="Estonia">Estonia</option>
			<option value="Ethiopia">Ethiopia</option>
			<option value="Falkland Islands">Falkland Islands</option>
			<option value="Faroe Islands">Faroe Islands</option>
			<option value="Fiji">Fiji</option>
			<option value="Finland">Finland</option>
			<option value="France">France</option>
			<option value="French Guiana">French Guiana</option>
			<option value="French Polynesia">French Polynesia</option>
			<option value="Gabon">Gabon</option>	
			<option value="Gambia">Gambia</option>
			<option value="Georgia">Georgia</option>
			<option value="Germany">Germany</option>
			<option value="Ghana">Ghana</option>
			<option value="Gibraltar">Gibraltar</option>
			<option value="Greece">Greece</option>
			<option value="Greenland">Greenland</option>
			<option value="Grenada">Grenada</option>	
			<option value="Guadeloupe">Guadeloupe</option>
			<option value="Guam">Guam</option>
			<option value="Guatemala">Guatemala</option>
			<option value="Guernsey">Guernsey</option>
			<option value="Guinea">Guinea</option>
			<option value="Guinea-Bissau">Guinea-Bissau</option>
			<option value="Guyana">Guyana</option>
			<option value="Haiti">Haiti</option>
			<option value="Holy See">Holy See</option>
			<option value="Honduras">Honduras</option>
			<option value="Hong Kong">Hong Kong</option>
			<option value="Hungary">Hungary</option>
			<option value="Iceland">Iceland</option>
			<option value="India">India</option>
			<option value="Indonesia">Indonesia</option>
			<option value="Iran">Iran</option>
			<option value="Iraq">Iraq</option>
			<option value="Ireland">Ireland</option>
			<option value="Isle of Man">Isle of Man</option>
			<option value="Israel">Israel</option>
			<option value="Italy">Italy</option>
			<option value="Jamaica">Jamaica</option>
			<option value="Japan">Japan</option>
			<option value="Jersey">Jersey</option>
			<option value="Jordan">Jordan</option>
			<option value="Kazakhstan">Kazakhstan</option>
			<option value="Kenya">Kenya</option>
			<option value="Kiribati">Kiribati</option>
			<option value="Korea">Korea</option>
			<option value="Kosovo">Kosovo</option>
			<option value="Kuwait">Kuwait</option>
			<option value="Kyrgyzstan">Kyrgyzstan</option>
			<option value="Laos">Laos</option>
			<option value="Latvia">Latvia</option>
			<option value="Lebanon">Lebanon</option>
			<option value="Lesotho">Lesotho</option>
			<option value="Liberia">Liberia</option>
			<option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
			<option value="Liechtenstein">Liechtenstein</option>
			<option value="Lithuania">Lithuania</option>
			<option value="Luxembourg">Luxembourg</option>
			<option value="Macao">Macao</option>
			<option value="Macedonia">Macedonia</option>
			<option value="Madagascar">Madagascar</option>
			<option value="Malawi">Malawi</option>
			<option value="Malaysia">Malaysia</option>
			<option value="Maldives">Maldives</option>
			<option value="Mali">Mali</option>
			<option value="Malta">Malta</option>
			<option value="Marshall Islands">Marshall Islands</option>
			<option value="Martinique">Martinique</option>
			<option value="Mauritania">Mauritania</option>
			<option value="Mauritius">Mauritius</option>
			<option value="Mayotte">Mayotte</option>
			<option value="Mexico">Mexico</option>
			<option value="Micronesia">Micronesia</option>
			<option value="Moldova">Moldova</option>
			<option value="Monaco">Monaco</option>
			<option value="Mongolia">Mongolia</option>
			<option value="Montenegro">Montenegro</option>
			<option value="Montserrat">Montserrat</option>
			<option value="Morocco">Morocco</option>
			<option value="Mozambique">Mozambique</option>
			<option value="Myanmar">Myanmar</option>
			<option value="Namibia">Namibia</option>
			<option value="Nauru">Nauru</option>
			<option value="Nepal">Nepal</option>
			<option value="Netherlands">Netherlands</option>
			<option value="New Caledonia">New Caledonia</option>
			<option value="New Zealand">New Zealand</option>
			<option value="Nicaragua">Nicaragua</option>
			<option value="Niger">Niger</option>
			<option value="Nigeria">Nigeria</option>
			<option value="Niue">Niue</option>
			<option value="Norfolk Island">Norfolk Island</option>
			<option value="Northern Mariana Islands">Northern Mariana Islands</option>
			<option value="Norway">Norway</option>
			<option value="Oman">Oman</option>
			<option value="Pakistan">Pakistan</option>
			<option value="Palau">Palau</option>
			<option value="Palestinian Territory">Palestinian Territory</option>
			<option value="Panama">Panama</option>
			<option value="Papua New Guinea">Papua New Guinea</option>
			<option value="Paraguay">Paraguay</option>
			<option value="Peru">Peru</option>
			<option value="Philippines">Philippines</option>
			<option value="Pitcairn">Pitcairn</option>
			<option value="Poland">Poland</option>
			<option value="Portugal">Portugal</option>
			<option value="Puerto Rico">Puerto Rico</option>
			<option value="Qatar">Qatar</option>
			<option value="Romania">Romania</option>
			<option value="Russia">Russia</option>
			<option value="Rwanda">Rwanda</option>
			<option value="Reunion">Reunion</option>
			<option value="Saint Barthelemy">Saint Barthelemy</option>
			<option value="Saint Helena">Saint Helena</option>
			<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
			<option value="Saint Lucia">Saint Lucia</option>
			<option value="Saint Martin">Saint Martin</option>
			<option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
			<option value="Saint Vincent">Saint Vincent</option>
			<option value="Samoa">Samoa</option>
			<option value="San Marino">San Marino</option>
			<option value="Sao Tome and Principe">Sao Tome and Principe</option>
			<option value="Saudi Arabia">Saudi Arabia</option>
			<option value="Senegal">Senegal</option>
			<option value="Serbia">Serbia</option>
			<option value="Seychelles">Seychelles</option>
			<option value="Sierra Leone">Sierra Leone</option>
			<option value="Singapore">Singapore</option>
			<option value="Slovakia">Slovakia</option>
			<option value="Slovenia">Slovenia</option>
			<option value="Solomon Islands">Solomon Islands</option>
			<option value="Somalia">Somalia</option>
			<option value="South Africa">South Africa</option>
			<option value="South Sudan">South Sudan</option>
			<option value="Spain">Spain</option>
			<option value="Sri Lanka">Sri Lanka</option>
			<option value="Sudan">Sudan</option>
			<option value="Suriname">Suriname</option>
			<option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
			<option value="Swaziland">Swaziland</option>
			<option value="Sweden">Sweden</option>
			<option value="Switzerland">Switzerland</option>
			<option value="Syrian Arab Republic">Syrian Arab Republic</option>
			<option value="Taiwan">Taiwan</option>
			<option value="Tajikistan">Tajikistan</option>
			<option value="Tanzania">Tanzania</option>
			<option value="Thailand">Thailand</option>
			<option value="Timor-Leste">Timor-Leste</option>
			<option value="Togo">Togo</option>
			<option value="Tokelau">Tokelau</option>
			<option value="Tonga">Tonga</option>
			<option value="Trinidad and Tobago">Trinidad and Tobago</option>
			<option value="Tunisia">Tunisia</option>
			<option value="Turkey">Turkey</option>
			<option value="Turkmenistan">Turkmenistan</option>
			<option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
			<option value="Tuvalu">Tuvalu</option>
			<option value="Uganda">Uganda</option>
			<option value="Ukraine">Ukraine</option>
			<option value="United Arab Emirates">United Arab Emirates</option>
			<option value="United Kingdom" selected>United Kingdom</option>
			<option value="United States">United States</option>
			<option value="Uruguay">Uruguay</option>
			<option value="Uzbekistan">Uzbekistan</option>
			<option value="Vanuatu">Vanuatu</option>
			<option value="Venezuela">Venezuela</option>
			<option value="Vietnam">Vietnam</option>
			<option value="Virgin Islands, British">Virgin Islands, British</option>
			<option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
			<option value="Wallis and Futuna">Wallis and Futuna</option>
			<option value="Yemen">Yemen</option>
			<option value="Zambia">Zambia</option>
			<option value="Zimbabwe">Zimbabwe</option>
		</select>
	</p>
	<p><input type="text" name="number" placeholder="Phone" style="width:90%;"></p>
	<p><input type="email" name="email" placeholder="Email" style="width:90%;"></p>
	<p>Number of Pets you have (please note, you must fill out a pet profile for each individual pet)
	<br><input type="number" name="petnumber" placeholder="*5"  style="width:90%;" required></p>
	<p>Pet's Name<span class="red">*</span>
	<br><input type="text" name="petname" placeholder="*Fido"  style="width:90%;" required></p>
	<p>Pet's Age / Birthdate(if known)<span class="red">*</span>
	<br><input type="text" name="petage" placeholder="*3 years old"  style="width:90%;" required></p>
	<p>Gender<span class="red">*</span>
	<br><input type="radio" name="petgender" value="Male" required>Male
	<br><input type="radio" name="petgender" value="Female">Female</p>
	<p>Neutered / Spayed?
	<br><input type="radio" name="petcondition" value="Yes">Yes
	<br><input type="radio" name="petcondition" value="No">No</p>
	<p>Pet's Breed<span class="red">*</span><br><input type="text" name="petbreed" placeholder="*Goldendoodle"  style="width:90%;" required></p>
	<p>Pet's Weight<br><input type="number" name="petweight" placeholder="*35"  style="width:90%;" required></p>
	<p>At Maturity, your pet should weigh....<br>
	<select name="petmaturedweight" style="width:90%;">
		<option value="teacup">5 lbs or less (Tea Cup)</option>
	</select></p>
	<p>Weight Category is<br>
	<select name="petweightcondition" style="width:90%;">
		<option value="normal">Normal</option>
		<option value="underweight">UNDERweight</option>
		<option value="overweight">OVERweight</option>
	</select></p>
	<p>Energy Level is:<br>
	<select name="petenergylevel" style="width:90%;">
		<option value="normal">Normal</option>
		<option value="low">Low</option>
		<option value="medium">Medium</option>
		<option value="high">High</option>
	</select></p>
	<p>What do you currently feed your pet?<br><input type="text" name="petfood" placeholder="*Purina Pro Plan - Salmon"  style="width:90%;" required></p>
	<p>What Food Form do you prefer(select all that apply):<span class="red">*</span><br>
	<input type="checkbox" name="petfoodoption[]" value="Dry Kibble">Dry Kibble<br>
	<input type="checkbox" name="petfoodoption[]" value="Canned">Canned</p>
	<p>Have you already ordered an Allergy Test from EasyDNA?<span class="red">*</span><br>
	<input type="radio" name="easydnatest" value="yes" required>Yes<br>
	<input type="radio" name="easydnatest" value="no">No<br>
	<input type="radio" name="easydnatest" value="whatsthat">What's That?</p>
	<p>If you have already ordered an Allergy Test from EasyDNA, please share your Allergy Barcode(s)with me here:
	<br><input type="number" name="barcode" style="width:90%;"></p>
	<p>If someone referred you to me, will you please share their name with me here?
	<br><input type="text" name="referalname" style="width:90%;"></p>
	<p>Comments - is there anything you'd like to share with me?
	<br><input type="text" name="comment" style="width:90%;"></p>
	<p><input type="submit" name="submit" value="Submit Pet Profile" style="width:80%; display:block; margin:auto;"></p>
</form>

</body>
</html>


<?php
if (!empty($_POST["petfoodoption"])) {
    $foodoption = "";
    foreach ($_POST["petfoodoption"] as $value) {
        $foodoption .= $value . ", ";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = 'INSERT INTO data_form_tb (First_Name, Last_Name, Address1, Address2, City, State, Postal_Code, Country, Phone, Email, Number_Of_Pet, Pet_Name, Pet_Age, Pet_Gender, Pet_Condition, Pet_Breed, Pet_Weight1, Pet_Weight2, Weight_Condition, Energy_Level, Pet_Food, Pet_Food_Form, Allergy_Test_Condition, Allergy_Test_Barcode, User_Referal, Comments)
VALUES (' . "'" . $_POST["firstname"] . "', " . "'" . $_POST["lastname"] . "', " . "'" . $_POST["address1"] . "', " . "'" . $_POST["address2"] . "', " . "'" . $_POST["city"] . "', " . "'" . $_POST["state"] . "', " . "'" . $_POST["postalcode"] . "', " . "'" . $_POST["country"] . "', " . "'" . $_POST["number"] . "', " . "'" . $_POST["email"] . "', " . "'" . $_POST["petnumber"] . "', " . "'" . $_POST["petname"] . "', " . "'" . $_POST["petage"] . "', " . "'" . $_POST["petgender"] . "', " . "'" . $_POST["petcondition"] . "', " . "'" . $_POST["petbreed"] . "', " . "'" . $_POST["petweight"] . "', " . "'" . $_POST["petmaturedweight"] . "', " . "'" . $_POST["petweightcondition"] . "', " . "'" . $_POST["petenergylevel"] . "', " . "'" . $_POST["petfood"] . "', " . "'" . $foodoption . "', " . "'" . $_POST["easydnatest"] . "', " . "'" . $_POST["barcode"] . "', " . "'" . $_POST["referalname"] . "', " . "'" . $_POST["comment"] . "'" . ')';
    
    if (mysqli_query($conn, $sql)) {
        echo "Success";
    } else {
        echo "Error " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>